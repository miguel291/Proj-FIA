﻿using UnityEngine;
using System.Collections;
using System.Linq;
using System;

public class CarDetectorGaussScript : CarDetectorScript {

	public float stdDev = 1.0f; 
	public float mean = 0.0f; 
	// Get gaussian output value
	public override float GetOutput1()
	{
		// YOUR CODE HERE

		return 0.0f;
	}
	public override float GetOutput2()
	{
		// YOUR CODE HERE

		return 0.0f;
	}


}
