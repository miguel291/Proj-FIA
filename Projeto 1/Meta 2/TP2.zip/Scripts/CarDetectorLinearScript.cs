﻿using UnityEngine;
using System.Collections;
using System.Linq;
using System;

public class CarDetectorLinearScript : CarDetectorScript {

	public override float GetOutput1()
	{
		return output;
	}
	public override float GetOutput2()
	{
		return output;
	}
	// YOUR CODE HERE




}
