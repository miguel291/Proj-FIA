﻿using UnityEngine;
using System.Collections;
using System.Linq;
using System;

public class CarDetectorLinearScript : CarDetectorScript {

	public override float GetOutput()
	{
		return output;
	}

	// YOUR CODE HERE




}
